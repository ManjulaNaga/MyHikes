const PATH="http://Custom-env.sayz9p6wvy.us-west-1.elasticbeanstalk.com";
const MyHike_PATH = "http://Custom-env.sayz9p6wvy.us-west-1.elasticbeanstalk.com";

// const PATH = "http://192.168.0.14:8080/myhikes";
// const MyHike_PATH = "http://192.168.0.14:8080/myhikes";

//const PATH = "http://134.154.42.2:8080/myhikes";
